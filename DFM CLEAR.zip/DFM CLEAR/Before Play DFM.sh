#!/bin/sh

hacker_echo() {
    local text="$1"
    local min_delay=0.01
    local max_delay=0.01
    local i=0

    printf "\033[32m"
    while [ $i -lt ${#text} ]; do
        printf "%s" "${text:$i:1}"
        sleep_time=$(echo "scale=4; $min_delay + ($RANDOM/32767) * ($max_delay - $min_delay)" | bc)
        sleep $sleep_time
        ((i++))
    done
    printf "\033[0m\n"
}

# Clearing iptables rules
iptables -F
iptables -X 
iptables -Z
iptables -t nat -F
hacker_echo "Local cache data processing succeeded"
# Clear iptables rules
iptables -F
hacker_echo "iptables rules cleared successfully"

ip6tables=/system/bin/ip6tables
iptables=/system/bin/iptables

#Delta Clear down
rm -rf /data/data/com.proxima.dfm/files/ano_tmp
rm -rf /data/user/0/com.proxima.dfm/files/ano_tmp

# Fix third-party environment exceptions
echo 16384 > /proc/sys/fs/inotify/max_queued_events
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 8192 > /proc/sys/fs/inotify/max_user_watches

# Clear Honor of Kings logs
hacker_echo "Cache data clearing completed"