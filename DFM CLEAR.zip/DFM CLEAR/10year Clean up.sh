#!/system/bin/sh
{
    APP_UID=$(dumpsys package com.proxima.dfm | grep uid= | awk '{print $1}' | cut -d'=' -f2 | uniq)
    sleep 1
    echo "当前三角洲Uid $APP_UID"
    echo "三角洲 自雷3/7清理  $APP_UID"
    sleep 1
    rm -rf /data/data/com.proxima.dfm/app_crashrecord
    rm -rf /data/data/com.proxima.dfm/app_crashSight
    rm -rf /data/data/com.proxima.dfm/app_dex
    rm -rf /data/data/com.proxima.dfm/app_midaslib_0
    rm -rf /data/data/com.proxima.dfm/app_midaslib_1
    rm -rf /data/data/com.proxima.dfm/app_midasodex
    rm -rf /data/data/com.proxima.dfm/app_midasplugins
    rm -rf /data/data/com.proxima.dfm/app_tbs
    rm -rf /data/data/com.proxima.dfm/app_tbs_64
    rm -rf /data/data/com.proxima.dfm/app_midasodex
    rm -rf /data/data/com.proxima.dfm//data/data/com.proxima.dfm/app_texturespp_tbs_64
    rm -rf /data/data/com.proxima.dfm/app_tbs_common_share
    rm -rf /data/data/com.proxima.dfm/app_textures
    rm -rf /data/data/com.proxima.dfm/app_turingdfp
    rm -rf /data/data/com.proxima.dfm/app_turingfd
    rm -rf /data/data/com.proxima.dfm/app_webview
    rm -rf /data/data/com.proxima.dfm/app_x5webview
    rm -rf /data/data/com.proxima.dfm/cache
    rm -rf /data/data/com.proxima.dfm/code_cache
    rm -rf /data/data/com.proxima.dfm/databases
    rm -rf /data/data/com.proxima.dfm/filescommonCache
    rm -rf /data/data/com.proxima.dfm/shared_prefs
    rm -rf /data/data/com.proxima.dfm/files/app
    rm -rf /data/data/com.proxima.dfm/files/beacon
    rm -rf /data/data/com.proxima.dfm/files/com.gcloudsdk.gcloud.gvoice
    rm -rf /data/data/com.proxima.dfm/files/data
    rm -rf /data/data/com.proxima.dfm/files/live_log
    rm -rf /data/data/com.proxima.dfm/files/popup
    rm -rf /data/data/com.proxima.dfm/files/tbs
    rm -rf /data/data/com.proxima.dfm/files/qm
    rm -rf /data/data/com.proxima.dfm/files/tdm_tmp
    rm -rf /data/data/com.proxima.dfm/files/wupSCache
    rm -rf /data/user/0/com.proxima.dfm/files/ano_tmp/
    rm -rf /data/data/com.proxima.dfm/files/apm_qcc_finally
    rm -rf /data/data/com.proxima.dfm/files/apm_qcc
    rm -rf /data/data/com.proxima.dfm/files/hawk_data
    rm -rf /data/data/com.proxima.dfm/files/itop_login.txt
    rm -rf /data/data/com.proxima.dfm/files/jwt_token.txt
    rm -rf /data/data/com.proxima.dfm/files/MSDK.mmap3
    rm -rf /data/data/com.proxima.dfm/files/com.tencent.tdm.qimei.sdk.QimeiSDK
    rm -rf /data/data/com.proxima.dfm/files/com.tencent.tbs.qimei.sdk.QimeiSDK
    rm -rf /data/data/com.proxima.dfm/files/com.tencent.qimei.sdk.QimeiSDK
    rm -rf /data/data/com.proxima.dfm/files/com.tencent.open.config.json.1110543085
    rm -rf /storage/emulated/0/Android/data/com.proxima.dfm/files
    rm -rf /storage/emulated/0/Android/data/com.proxima.dfm/files
    rm -rf /storage/emulated/0/Android/data/com.proxima.dfm/cache
    rm -rf /storage/emulated/0/Android/data/com.proxima.dfm/files
    rm -rf /data/user/0/com.proxima.dfm/app_crashrecord
    rm -rf /data/user/0/com.proxima.dfm/app_crashSight
    rm -rf /data/user/0/com.proxima.dfm/app_databases
    rm -rf /data/user/0/com.proxima.dfm/app_msdk
    rm -rf /data/user/0/com.proxima.dfm/app_turingdfp
    rm -rf /data/user/0/com.proxima.dfm/app_turingfd
    rm -rf /data/user/0/com.proxima.dfm/app_turingsmi
    rm -rf /data/user/0/com.proxima.dfm/cache
    rm -rf /data/user/0/com.proxima.dfm/databases
    rm -rf /data/user/0/com.proxima.dfm/shared_prefs
    rm -rf /data/user/0/com.proxima.dfm/files/app
    rm -rf /data/user/0/com.proxima.dfm/files/beacon
    rm -rf /data/user/0/com.proxima.dfm/files/com.gcloudsdk.gcloud.gvoice
    rm -rf /data/user/0/com.proxima.dfm/files/data
    rm -rf /data/user/0/com.proxima.dfm/files/popup
    rm -rf /data/user/0/com.proxima.dfm/files/qm
    rm -rf /data/user/0/com.proxima.dfm/files/tdm_tmp 
    rm -rf /data/user/0/com.proxima.dfm/files/.iii
    rm -rf /data/user/0/com.proxima.dfm/files/.system_android_l2
    rm -rf /data/user/0/com.proxima.dfm/files/ace_shell_di.dat
    rm -rf /data/user/0/com.proxima.dfm/files/apm_qcc
    rm -rf /data/user/0/com.proxima.dfm/files/apm_qcc_finally
    rm -rf /data/user/0/com.proxima.dfm/files/apm_qcc_preonce
    rm -rf /data/user/0/com.proxima.dfm/files/apm_qcc_preonce_cache
    rm -rf /data/user/0/com.proxima.dfm/files/com.tencent.qimei.sdk.QimeiSDK
    rm -rf /data/user/0/com.proxima.dfm/files/com.tencent.tdm.qimei.sdk.QimeiSDK
    rm -rf /data/user/0/com.proxima.dfm/files/com.proxima.dfm_core_godcmd_history
    rm -rf /data/user/0/com.proxima.dfm/files/libwbsafeedit_64.so
    rm -rf /data/user/0/com.proxima.dfm/files/login-identifier.txt
    rm -rf /data/user/0/com.proxima.dfm/files/MSDK.mmap3
    rm -rf /data/user/0/com.proxima.dfm/files/tdm_counter
    rm -rf /data/user/0/com.proxima.dfm/files/tdm_track.dat
    rm -rf /data/user/0/com.proxima.dfm/files/TRI_CM_AUDIT
    rm -rf /data/user/0/com.proxima.dfm/files/tri_init
    rm -rf /data/user/0/com.proxima.dfm/files/UE4Game/DeltaForce/Manifest_UFSFiles_Android.txt
    rm -rf /data/user/0/com.proxima.dfm/files/UE4Game/DeltaForce/DeltaForce/Intermediate
    rm -rf /data/user/0/com.proxima.dfm/files/UE4Game/DeltaForce/DeltaForce/Saved/Config
    rm -rf /data/user/0/com.proxima.dfm/files/UE4Game/DeltaForce/DeltaForce/Saved/Dolphin
    rm -rf /data/user/0/com.proxima.dfm/files/UE4Game/DeltaForce/DeltaForce/Saved/Gamelet
    rm -rf /data/user/0/com.proxima.dfm/files/UE4Game/DeltaForce/DeltaForce/Saved/pixuicache
    rm -rf /data/user/0/com.proxima.dfm/files/UE4Game/DeltaForce/DeltaForce/Saved/pixuicache
    rm -rf /data/data/com.proxima.dfm/files/ano_tmp
    rm -rf /data/data/com.proximabeta.mf.uamo/files/ano_tmp
    rm -rf /data/user/0/com.proximabeta.mf.uamo/files/ano_tmp
    rm -rf /data/user/0/com.proxima.dfm/files/ano_tmp
    rm -rf /storage/emulated/0/Android/data/com.proxima.dfm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
    rm -rf /storage/emulated/0/Android/data/com.proxima.dfm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
    echo 16384 > /proc/sys/fs/inotify/max_queued_events
    echo 128 > /proc/sys/fs/inotify/max_user_instances
    echo 8192 > /proc/sys/fs/inotify/max_user_watches
    
    iptables -F
    iptables -X 
    iptables -Z
    iptables -t nat -F 
    echo "本地缓存数据处理成功"
    #清楚iptables规则
    iptables -F
    echo "iptables规则清除成功"
    ip6tables=/system/bin/ip6tables
    iptables=/system/bin/iptables
    
    echo "执行初始化IP..."
    INTERFACE="wlan0"
    IP=$(ip addr show $INTERFACE | grep 'inet ' | grep -v '127.0.0.1' | awk '{print $2}' | cut -d/ -f1)
    IP_PREFIX=$(echo $IP | cut -d. -f1-3)
    NEW_IP_LAST_PART1=$(($RANDOM % 254 + 1))
    NEW_IP_LAST_PART2=$(($RANDOM % 254 + 1))
    NEW_IP1="${IP_PREFIX}.${NEW_IP_LAST_PART1}"
    NEW_IP2="${IP_PREFIX}.${NEW_IP_LAST_PART2}"
    ip addr add $NEW_IP1/24 dev $INTERFACE
    ip addr add $NEW_IP2/24 dev $INTERFACE
    
    echo "原始网络IP地址是: $IP"
             
    settings put global airplane_mode_on 1
    am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true         
    prog_name="/data/temp"
    name=$(tr -dc \'1-9\' < /dev/urandom | head -c 8)
    while echo "$name" | grep -q "'"
    do
    name=$(tr -dc \'1-9\' < /dev/urandom | head -c 8)
    done 
    yy=$(getprop ro.serialno)
    resetprop ro.serialno $name
    echo 
    yy=$(getprop ro.serialno)
    settings put global airplane_mode_on 0
    am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false
    echo "改变IP完毕"            

	clear
	Pf_R() { sleep 0.$RANDOM ;echo "\a\033[5m\033[31m[-]$@" ;sleep 0.$RANDOM ;echo "\033[1A\033[2K\r\a\033[33m[\\]$@\033[K" ;}
	Pf_A() { sleep 0.$RANDOM ;echo "\033[1A\033[2K\r\a\033[32m[+]$*\033[K" ;echo ;}
	Id_Path=/data/system/users/0
	rm -rf $Id_Path/registered_services $Id_Path/app_idle_stats.xml
	Id_File=$Id_Path/settings_ssaid.xml
	abx2xml -i $Id_File
	View_id() { grep $1 $Id_File | awk -F '"' '{print $6}' ;}
	Random_Id_1() { cat /proc/sys/kernel/random/uuid ;}
	Amend_Id() { sed -i "s#$1#$2#g" $Id_File ;}
	Userkey_Uid=`View_id userkey`
	Pf_R 系统UUID：$Userkey_Uid
	Amend_Id $Userkey_Uid $(echo `Random_Id_1``Random_Id_1` | tr -d - | tr a-z A-Z)
	printf "\033[1A\033[2K"
	printf "\033[1A\033[2K"
	Pf_A 系统UUID：`View_id userkey`
	Pf_R 三角洲清理中
	Pkg=com.proxima.dfm ;am force-stop $Pkg
	Tmp=/data/media/0/Android/data/$Pkg ;rm -rf $Tmp/files/UE4Game/UAGame/UAGame/Saved/!(dlc) $Tmp/files/UE4Game/UAGame/UAGame/Saved/dlc/puffer_temp/ $Tmp/files/!(UE4Game) $Tmp/files/.* $Tmp/files/TGPA $Tmp/files/ProgramBinaryCache $Tmp/cache /data/data/$Pkg/* $Tmp/files/UE4Game/UAGame/!(Engine|UAGame)
	Pf_A 已三角洲清理
	Pkg_Aid=`View_id com.proxima.dfm`
	Pf_R 三角洲AID：$Pkg_Aid
	Amend_Id $Pkg_Aid `Random_Id_1 | tr -d - | head -c 16`
	Pf_A 三角洲AID：`View_id com.proxima.dfm`
	xml2abx -i $Id_File
	Random_Id_2() {
		Min=$1
		Max=$(($2 - $Min + 1))
		Num=`cat /dev/urandom | head | cksum | awk -F ' ' '{print $1}'`
		echo $(($Num % $Max + $Min))
	}
	Serial_Id=/sys/devices/soc0/serial_number
	Pf_R 主板ID：`cat $Serial_Id`
	Tmp=/sys/devices/virtual/kgsl/kgsl/full_cache_threshold
	Random_Id_2 1100000000 2000000000 > $Tmp
	mount | grep -q $Serial_Id && umount $Serial_Id
	mount --bind $Tmp $Serial_Id
	Pf_A 主板ID：`cat $Serial_Id`
	IFS=$'\n'
	for i in `getprop | grep imei | awk -F '[][]' '{print $2}'`
	do
		Imei=`getprop $i`
		[ `echo $Imei | wc -c` -lt 16 ] && continue
		let a++
		printf "\r\033[31m[-]IMEI：$Imei\033[K"
		printf "\r\033[33m[\\]IMEI：$Imei\033[K"
		resetprop $i `echo $((RANDOM % 80000 + 8610000))00000000`
		printf "\r\033[32m[+]IMEI：`getprop $i`\033[K"
	done
	sleep 0.88s
	printf "\r[+]IMEI：Reset $a⁺\033[K"
	echo \\n
	Oa_Id=/data/system/oaid_persistence_0
	Pf_R OAID：`cat $Oa_Id`
	printf `Random_Id_1 | tr -d - | head -c 16` > $Oa_Id
	Pf_A OAID：`cat $Oa_Id`
	Va_Id=/data/system/vaid_persistence_platform
	Pf_R VAID：`cat $Va_Id`
	printf `Random_Id_1 | tr -d - | head -c 16` > $Va_Id
	Pf_A VAID：`cat $Va_Id`
	Pf_R 序列号：`getprop ro.serialno`
	resetprop ro.serialno `Random_Id_1 | head -c 8`
	Pf_A 序列号：`getprop ro.serialno`
	Pf_R 设备ID：`settings get secure android_id`
	settings put secure android_id `Random_Id_1 | tr -d - | head -c 16`
	Pf_A 设备ID：`settings get secure android_id`
	Pf_R 版本ID：`getprop ro.build.id`
	resetprop ro.build.id UKQ1.$((RANDOM % 20000 + 30000)).001
	Pf_A 版本ID：`getprop ro.build.id`
	Pf_R CPU_ID：`getprop ro.boot.cpuid`
	resetprop ro.boot.cpuid 0x00000`Random_Id_1 | tr -d - | head -c 11`
	Pf_A CPU_ID：`getprop ro.boot.cpuid`
	Pf_R OEM_ID：`getprop ro.ril.oem.meid`
	resetprop ro.ril.oem.meid 9900$((RANDOM % 8000000000 + 1000000000))
	Pf_A OEM_ID：`getprop ro.ril.oem.meid`
	Pf_R 广告ID：`settings get global ad_aaid`
	settings put global ad_aaid `Random_Id_1`
	Pf_A 广告ID：`settings get global ad_aaid`
	Pf_R UUID：`settings get global extm_uuid`
	settings put global extm_uuid `Random_Id_1`
	Pf_A UUID：`settings get global extm_uuid`
	Pf_R 指纹UUID：`settings get system key_mqs_uuid`
	settings put system key_mqs_uuid `Random_Id_1`
	Pf_A 指纹UUID：`settings get system key_mqs_uuid`
	Sum=$(getprop ro.build.fingerprint)
	sleep 0.$RANDOM
	echo "\a\033[5m\033[31m[-]指纹密钥：$Sum"
	sleep 0.$RANDOM
	printf "\033[1A\033[2K"
	echo "\033[1A\033[2K\a\033[5m\033[33m[\\]指纹密钥：$Sum"
	sleep 0.$RANDOM
	printf "\033[1A\033[2K"
	for i in $(seq 1 $(echo "$Sum" | grep -o [0-9] | wc -l))
	do
		Sum=$(echo "$Sum" | sed "s/[0-9]/$(($RANDOM % 10))/$i")
	done
	resetprop ro.build.fingerprint "$Sum"
	echo "\033[1A\033[2K\a\033[5m\033[32m[+]指纹密钥：$(getprop ro.build.fingerprint)\n"
	Pf_R GC驱动器ID：`settings get global gcbooster_uuid`
	settings put global gcbooster_uuid `Random_Id_1`
	Pf_A GC驱动器ID：`settings get global gcbooster_uuid`
	Pf_R IP地址：`curl -s ipinfo.io/ip`
	svc data disable
	svc wifi disable
	sleep 5
	svc data enable
	svc wifi enable
	until ping -c 1 223.5.5.5 &>/dev/null
	do
		sleep 1
	done
	Pf_A IP地址：`curl -s ipinfo.io/ip`
	IFS=$'\n'
	Mac_File=/sys/class/net/wlan0/address
	Pf_R Wifi_Mac地址：`cat $Mac_File`
	mount | grep -q $Mac_File && umount $Mac_File
	svc wifi disable
	ifconfig wlan0 down
	sleep 1
	Mac=`Random_Id_1 | sed 's/-//g ;s/../&:/g' | head -c 17`
	ifconfig wlan0 hw ether $Mac
	for Wlan_Path in `find /sys/devices -name wlan0`
	do
		[ -f "$Wlan_Path/address" ] && {
			chmod 644 "$Wlan_Path/address"
			echo $Mac > "$Wlan_Path/address"
		}
	done
	chmod 0755 $Mac_File
	echo $Mac > $Mac_File
	for Wlan_Path in `find /sys/devices -name '*,wcnss-wlan'`
	do
		[ -f "$Wlan_Path/wcnss_mac_addr" ] && {
			chmod 644 "$Wlan_Path/wcnss_mac_addr"
			echo $Mac > "$Wlan_Path/wcnss_mac_addr"
		}
	done
	Tmp=/data/local/tmp/Mac_File
	echo $Mac > $Tmp
	mount --bind $Tmp $Mac_File
	ifconfig wlan0 up
	svc wifi enable
	sleep 1
	Pf_A Wifi_Mac地址：`cat $Mac_File`
	echo \\033[38m已完成	
} 2>/dev/null